// Request logger middleware
const logger = (req, res, next) => {
  const start = Date.now();
  const timestamp = new Date().toISOString();

  res.on("finish", () => {
    const duration = Date.now() - start;
    const statusColor =
      res.statusCode >= 500
        ? "\x1b[31m" // red
        : res.statusCode >= 400
        ? "\x1b[33m" // yellow
        : res.statusCode >= 200
        ? "\x1b[32m" // green
        : "\x1b[36m"; // cyan

    console.log(
      `\x1b[90m[${timestamp}]\x1b[0m ${req.method} ${req.originalUrl} → ${statusColor}${res.statusCode}\x1b[0m \x1b[90m(${duration}ms)\x1b[0m`
    );
  });

  next();
};

module.exports = logger;
